import Q1
import Q2
import Q3

print("|| Task 1: Breadth First Search ||")
Q1.ucs_noenergy('1', '50')

print("\n|| Task 2: Uniform Cost Search ||\n")
Q2.ucs('1', '50')

print("\n|| Task 3: A* Search ||\n")
Q3.updatedAStar('1', '50',1.22)